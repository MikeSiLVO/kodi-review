"""KDK - Kodi skin validation tool."""

__version__ = "3.1.0+513cf7e"
