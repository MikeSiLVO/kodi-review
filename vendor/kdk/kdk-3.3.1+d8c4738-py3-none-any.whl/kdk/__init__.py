"""KDK - Kodi skin validation tool."""

__version__ = "3.3.1+d8c4738"
