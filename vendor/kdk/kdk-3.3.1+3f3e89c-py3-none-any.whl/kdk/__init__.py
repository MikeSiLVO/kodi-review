"""KDK - Kodi skin validation tool."""

__version__ = "3.3.1+3f3e89c"
