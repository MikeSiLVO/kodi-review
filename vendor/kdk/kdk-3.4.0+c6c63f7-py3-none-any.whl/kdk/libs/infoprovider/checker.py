"""InfoProvider mixin that runs the validators and the per-file checks."""

from __future__ import annotations

import os
import copy
import logging
from ..utils.xml import (check_brackets, get_root_from_file, parse_error_issue, tag_start_line,
                         tolerated_xml_errors, tree_needs_expansion)
from ..utils.expressions import (
    contains_dynamic_expression,
    extract_number_value,
    extract_variable_name,
    flatten_expressions,
    is_dynamic_expression,
    is_number,
)
from ..utils.validation import create_issue, deduplicate_issues, is_runtime_generated_file, merge_include_issues
from ..addon.translations import get_po_file
from ..infonames import from_tree
from ..utils.infobool import info_name_sets, is_known_info, static_value
from ..utils.colors import is_kodi_hex
from ..validation.font import ValidationFont
from ..validation.image import ValidationImage
from ..validation.ids import ValidationIds
from ..validation.label import ValidationLabel
from ..validation.include import ValidationInclude
from ..validation.variable import ValidationVariable
from ..validation.skinmap import ValidationMap
from ..validation.filecheck import ValidationFileCheck
from ..validation.repo import ValidationRepo
from ..validation.include import check_include_file_ref
from ..validation.suppress import scan, skin_paths, stamp
from ..validation.interpreter import STRUCTURAL_TAGS, XmlInterpreter
from ..validation.urls import UrlValues, value_sources
from ..validation.hierarchy import ALL_LAYOUT_TAGS
from ..validation.constants import (
    BRACKET_TAGS,
    LITERAL_TAGS,
    INCLUDE_DEFINITION_TAGS,
    NOOP_TAGS,
    REPEATABLE_TAGS,
    is_read_copy,
    attribute_bool_problem,
    viewtype_problem,
    ALLOWED_MULTI,
    ALLOWED_VALUES,
    CASE_INSENSITIVE_ENUMS,
    SEVERITY_ERROR,
    SEVERITY_WARNING,
    SEVERITY_HINT,
    EMPTY_VISIBLE,
)

from typing import Any

logger = logging.getLogger(__name__)

# every hover re-enters get_po_files; keyed by mtime so a refreshed snapshot reloads
_CORE_PO_CACHE: dict = {}


def _core_po(path):
    """Parsed Kodi-core strings.po at the path, reusing the last parse."""
    try:
        stamp = os.path.getmtime(path)
    except OSError:
        stamp = None
    cached = _CORE_PO_CACHE.get(path)
    if cached and cached[0] == stamp:
        return cached[1]
    po = get_po_file(path)
    if po is not None:
        po.language = "resource.language.en_gb"  # type: ignore[attr-defined]
        _CORE_PO_CACHE[path] = (stamp, po)
    return po


class CheckerMixin:
    """Mixin running every check, the validators and the per-file ones."""

    addon: Any
    template_attribs: dict
    template_values: dict
    settings: dict
    WINDOW_IDS: list
    WINDOW_NAMES: list
    WINDOW_FILENAMES: list
    OBSOLETE_WINDOW_FILES: dict
    INFO_NAMES: dict
    MODELESS_IDS: set
    DIALOG_IDS: set
    _variable_cache: dict
    info_source: str = "snapshot"

    def known_info_names(self) -> dict:
        """Get kodi_path's info names, else the bundled ones; records which and notes a bad read."""
        kodi_path = (self.settings.get("kodi_path") or "").strip() if self.settings else ""
        try:
            found = from_tree(kodi_path) if kodi_path else None
        except (OSError, ValueError) as e:
            if self.addon:
                self.addon.add_notice(f"Info names in {kodi_path} could not be read ({e}), "
                                      f"so the bundled list is used")
            found = None
        self.info_source = "snapshot" if found is None else "checkout"
        return self.INFO_NAMES if found is None else info_name_sets(found)

    def get_po_files(self) -> list:
        """Get the skin's PO files plus Kodi-core strings.po from kodi_path or the snapshot."""
        from ..coredata import kodi_strings_po

        po_files = []
        seen = set()

        def _add(po):
            if po is None or id(po) in seen:
                return
            seen.add(id(po))
            po_files.append(po)

        if self.addon and hasattr(self.addon, "po_files"):
            for po in self.addon.po_files:
                _add(po)

        kodi_path = (self.settings.get("kodi_path") or "").strip() if self.settings else ""
        core_po_path = kodi_strings_po(self.addon, kodi_path or None)
        if core_po_path:
            try:
                _add(_core_po(core_po_path))
            except Exception as e:
                logger.warning("Failed to load Kodi-core strings.po (%s): %s", core_po_path, e)

        return po_files

    def get_color_labels(self) -> set:
        """Get the color names the skin defines, empty without an addon."""
        if self.addon and hasattr(self.addon, "color_labels"):
            return self.addon.color_labels
        return set()

    def _get_includes_for_folder(self, folder: str) -> list:
        """Get the folder's include, variable and default maps as one list of rows."""
        if not self.addon:
            return []

        if not hasattr(self.addon, "include_map"):
            return []

        from ..skin.include import SkinInclude

        result = []
        for name, (node, params, file_path) in self.addon.include_map.get(folder, {}).items():
            definition = node.find("definition")
            include_body = definition if definition is not None else node
            inc = SkinInclude(node=include_body, file=file_path)
            result.append({
                "name": name, "type": "include",
                "file": inc.file, "line": inc.line,
                "content": inc.content, "node": inc.node,
                "params": params,
            })

        for name, (node, file_path) in self.addon.variable_map.get(folder, {}).items():
            inc = SkinInclude(node=node, file=file_path)
            result.append({
                "name": name, "type": "variable",
                "file": inc.file, "line": inc.line,
                "content": inc.content, "node": inc.node,
            })

        for control_type, (node, file_path) in self.addon.default_map.get(folder, {}).items():
            inc = SkinInclude(node=node, file=file_path)
            result.append({
                "name": control_type, "type": "default",
                "file": inc.file, "line": inc.line,
                "content": inc.content, "node": inc.node,
            })

        return result

    def resolve_xml(self, path_or_root, *, folder=None, strict=False):
        """Resolve a skin's tree or file on a copy; on failure None or the input, or raise."""
        from ..skin.skin import Skin

        if hasattr(path_or_root, "tag"):
            root = path_or_root
            src_path = None
        else:
            src_path = str(path_or_root)
            root = get_root_from_file(src_path)
            if root is None:
                if strict:
                    raise RuntimeError(f"XML parse failed: {src_path}")
                return None

        sk = self.addon
        if not isinstance(sk, Skin):
            return root

        f = folder
        if not f and src_path:
            f = sk.xml_folder_of(src_path) or None
        if not f and sk.xml_folders:
            f = sk.xml_folders[0]
        if not f:
            return root

        try:
            # resolve() mutates in place
            resolved_root = copy.deepcopy(root)
            sk.resolver.resolve(resolved_root, f)
            return resolved_root
        except Exception:
            if strict:
                raise
            return root

    def get_check_listitems(self, check_type, progress_callback=None):
        """Get the rows of the named check, or one row saying the check type is unknown."""
        checks = {
            "general": self.check_values,
            "file": self.check_values,
            "variable": self.check_variables,
            "map": self.check_maps,
            "include": self.check_includes,
            "font": self.check_fonts,
            "label": self.check_labels,
            "id": self.check_ids,
            "image": self.check_images,
            "filecheck": self.check_file_integrity,
            "repo": self.check_repo,
        }
        fn = checks.get(check_type)
        if not fn:
            logger.info("[checks] handler missing type=%s", check_type)
            return [{"message": "Unknown check type", "file": "", "line": 0,
                     "rule": "kdk.unknown-check-type", "subject": check_type}]
        return fn(progress_callback=progress_callback) or []

    def get_suppressions(self):
        """Get the skin's `kdk-ignore` directives, rescanned once any of its xml files changes."""
        paths = skin_paths(self.addon)
        files = stamp(paths)
        cached = getattr(self, "_suppressions", None)
        if cached is None or cached[0] != files:
            cached = self._suppressions = (files, scan(paths))
        return cached[1]

    def get_value_sources(self):
        """Get what the skin stores in properties and skin strings, rescanned on a file change."""
        paths = skin_paths(self.addon)
        files = stamp(paths)
        cached = getattr(self, "_value_sources", None)
        if cached is None or cached[0] != files:
            cached = self._value_sources = (files, value_sources(paths))
        return cached[1]

    def _variable_values(self, folder):
        """Each variable's <value> texts by name, rebuilt for a new map."""
        variables = getattr(self.addon, "variable_map", {}).get(folder, {})
        cache = vars(self).setdefault("_variable_cache", {})
        if folder not in cache or cache[folder][0] is not variables:
            table = {name: [value.text or "" for value in entry[0].findall("value")]
                     for name, entry in variables.items()}
            cache[folder] = (variables, table)
        return cache[folder][1]

    def _reported(self, category, issues):
        """Drop generated-file rows, move rows to their tag's first line, mark kdk-ignore mutes."""
        kept = []
        for issue in issues:
            path, line = issue.get("file") or "", issue.get("line") or 0
            if is_runtime_generated_file(path):
                continue
            first = tag_start_line(path, line) if line and path.lower().endswith(".xml") else line
            kept.append({**issue, "line": first} if first != line else issue)
        issues = kept
        if not self.addon or not issues:
            return issues
        return self.get_suppressions().mark(category, issues)

    def get_validation_index(self, progress_callback=None):
        """Get the cached validation index, building it on first access."""
        if not self.addon:
            return None

        # test mocks may lack the index
        if not hasattr(self.addon, 'validation_index'):
            return None
        if not hasattr(self.addon, 'index_builder'):
            return None

        if self.addon.validation_index is None:
            self.addon.validation_index = self.addon.index_builder.build_validation_index(progress_callback=progress_callback)

        return self.addon.validation_index

    def check_variables(self, progress_callback=None):
        """Check the skin's variables for undefined, unused or shadowed ones."""
        if not self.addon:
            return []

        checker = ValidationVariable(self.addon)
        return self._reported("Variables", checker.check(progress_callback=progress_callback))

    def check_maps(self, progress_callback=None):
        """Check the skin's maps for malformed, undefined or unused ones."""
        if not self.addon:
            return []

        checker = ValidationMap(self.addon)
        return self._reported("Maps", checker.check(progress_callback=progress_callback))

    def check_includes(self, progress_callback=None):
        """Check includes for undefined, unused or shadowed ones and a miscased Includes.xml."""
        if not self.addon:
            return []

        checker = ValidationInclude(self.addon)
        return self._reported("Includes", checker.check(progress_callback=progress_callback))

    def check_fonts(self, progress_callback=None):
        """Check the skin's fonts, their files and fontsets, and where they are used."""
        if not self.addon:
            return []

        index = self.get_validation_index(progress_callback=progress_callback)
        checker = ValidationFont(self.addon, resolve_include_fn=self.resolve_xml,
                                 validation_index=index)
        return self._reported("Fonts", checker.check(progress_callback=progress_callback))

    def check_ids(self, progress_callback=None):
        """Check the skin's id references, window names and custom windows."""
        if not self.addon:
            return []

        index = self.get_validation_index(progress_callback=progress_callback)
        checker = ValidationIds(self.addon, self.WINDOW_IDS, self.WINDOW_NAMES, validation_index=index,
                                window_filenames=self.WINDOW_FILENAMES, modeless_ids=self.MODELESS_IDS,
                                dialog_ids=self.DIALOG_IDS)
        return self._reported("IDs", checker.check(progress_callback=progress_callback))

    def check_labels(self, progress_callback=None):
        """Check the skin's labels for bad ids, broken strings and untranslated text."""
        if not self.addon:
            return []

        index = self.get_validation_index(progress_callback=progress_callback)
        checker = ValidationLabel(self.addon, self.get_po_files, validation_index=index,
                                  info_names=self.known_info_names())
        return self._reported("Labels", checker.check(progress_callback=progress_callback))

    def check_repo(self, progress_callback=None):
        """Check addon.xml, artwork, language files and file types against the Kodi repo rules."""
        if not self.addon:
            return []

        checker = ValidationRepo(self.addon)
        return self._reported("Kodi Repo", checker.check(progress_callback=progress_callback))

    def check_file_integrity(self, progress_callback=None):
        """Check the skin's files for BOMs, line endings, 16-bit PNGs, broken strings, bad types."""
        if not self.addon:
            return []

        checker = ValidationFileCheck(self.addon)
        return self._reported("File Integrity", checker.check(progress_callback=progress_callback))

    def check_images(self, progress_callback=None):
        """Check the skin's bundles and images for missing, miscased or misplaced files."""
        if not self.addon:
            return []

        index = self.get_validation_index(progress_callback=progress_callback)
        checker = ValidationImage(self.addon, validation_index=index, window_filenames=self.WINDOW_FILENAMES)
        return self._reported("Images", checker.check(progress_callback=progress_callback))

    def check_values(self, progress_callback=None):
        """Check every XML file as check_file does, merging per-call include rows."""
        if not self.addon:
            return []

        listitems = []
        xml_files = list(self.addon.get_xml_files())
        total_files = len(xml_files)

        if progress_callback:
            progress_callback(f"Validating {total_files} XML files...")

        for index, path in enumerate(xml_files, 1):
            if progress_callback:
                progress_callback(f"Validating {os.path.basename(path)} ({index}/{total_files})...")
            result = self._file_issues(path)
            if result:
                listitems.extend(result)

        listitems = self._reported("XML Validation", deduplicate_issues(merge_include_issues(listitems)))
        listitems += self.get_suppressions().faults_in()

        if progress_callback:
            progress_callback(f"Complete: {len(listitems)} XML validation issues found")

        return listitems

    def _add_issue(self, listitems, node, message, identifier="", severity=SEVERITY_WARNING, *, rule,
                   subject=None):
        """Add an issue at the element's line; _file_issues adds the file later."""
        issue = create_issue(
            message=message,
            file="",
            line=node.sourceline,
            type=node.tag,
            identifier=identifier or node.tag,
            rule=rule,
            subject=(identifier or node.tag) if subject is None else subject,
        )
        issue["severity"] = severity
        listitems.append(issue)

    def _validate_brackets(self, listitems, node, text):
        """Validate a condition, reporting it if empty or unbalanced; returns whether it passed."""
        if not text:
            if node.tag == "visible":
                self._add_issue(listitems, node, EMPTY_VISIBLE, severity=SEVERITY_HINT, rule="xml.empty-condition")
            else:
                self._add_issue(listitems, node, f"Empty condition: {node.tag}", severity=SEVERITY_ERROR,
                                rule="xml.empty-condition")
            return False
        if is_dynamic_expression(text):
            return True
        if not check_brackets(text):
            condition = text.replace("  ", "").replace("\t", "")
            self._add_issue(listitems, node, f"Brackets do not match: {condition}", condition, severity=SEVERITY_ERROR,
                            rule="xml.bad-brackets")
            return False
        return True

    def _validate_enum_value(self, listitems, node, value, value_type, attr_name=None):
        """Validate a value against ALLOWED_VALUES, reporting a miss; returns whether it passed."""
        if value_type not in ALLOWED_VALUES:
            return True
        if is_dynamic_expression(value):
            return True
        if value_type == "viewtype":
            problem = viewtype_problem(value)
            if problem:
                self._add_issue(listitems, node, problem, value, severity=SEVERITY_WARNING,
                                rule="xml.unknown-viewtype")
            return problem is None

        # Kodi lowercases these before comparing
        if value_type in CASE_INSENSITIVE_ENUMS:
            normalized_value = value.lower()
            if normalized_value not in ALLOWED_VALUES[value_type]:
                location = f"{attr_name} attribute" if attr_name else node.tag
                allowed = ", ".join(sorted(ALLOWED_VALUES[value_type]))
                self._add_issue(listitems, node, f"invalid value for {location}: {value} (allowed: {allowed})", value,
                                severity=SEVERITY_ERROR, rule="xml.invalid-value", subject=attr_name or node.tag)
                return False
        else:
            if value not in ALLOWED_VALUES[value_type]:
                location = f"{attr_name} attribute" if attr_name else node.tag
                if value.lower() in ALLOWED_VALUES[value_type]:
                    detail = "must be lowercase"
                elif value_type == "sort":
                    detail = "not a sort method Kodi knows, so the items keep the order the source gives"
                else:
                    detail = "allowed: " + ", ".join(sorted(ALLOWED_VALUES[value_type]))
                self._add_issue(listitems, node, f"invalid value for {location}: {value} ({detail})", value,
                                severity=SEVERITY_ERROR, rule="xml.invalid-value", subject=attr_name or node.tag)
                return False
        return True

    def _validate_variable_values(self, listitems, node, var_text, value_type, folder, tag_name=None):
        """Validate each $VAR value for the tag's type, reporting misses; True when all pass."""
        var_name = extract_variable_name(var_text)
        if not var_name:
            return True

        var_node = getattr(self, '_variable_cache', {}).get(var_name)
        if var_node is None:
            return True  # undefined vars are the variable check's job

        value_nodes = var_node.findall("value")

        if not value_nodes:
            return True

        all_valid = True
        for value_node in value_nodes:
            value_text = (value_node.text or "").strip()
            if not value_text or contains_dynamic_expression(value_text):
                continue

            is_valid = True
            if value_type == "color" and getattr(self.addon, "type", None) == "skin":
                is_valid = (value_text in self.get_color_labels() or value_text in self.addon.theme_colors
                            or is_kodi_hex(value_text))
                if not is_valid:
                    location = tag_name if tag_name else node.tag
                    self._add_issue(
                        listitems, node,
                        f"Variable ${var_name} used in <{location}> has invalid color value: {value_text}",
                        value_text, rule="xml.invalid-variable-value", subject=var_name,
                    )
            elif value_type in ["int", "position"]:
                check_val = value_text.rstrip("%r") if value_type == "position" else value_text
                number_value = extract_number_value(value_text)
                if number_value:
                    check_val = number_value
                is_valid = is_number(check_val) or (self.addon and value_text in self.addon.get_constants(folder))
                if not is_valid:
                    location = tag_name if tag_name else node.tag
                    self._add_issue(
                        listitems, node,
                        f"Variable ${var_name} used in <{location}> has invalid integer value: {value_text}",
                        value_text, rule="xml.invalid-variable-value", subject=var_name,
                    )
            elif value_type in ALLOWED_VALUES:
                read = value_text.lower() if value_type in CASE_INSENSITIVE_ENUMS else value_text
                is_valid = read in ALLOWED_VALUES[value_type]
                if not is_valid:
                    location = tag_name if tag_name else node.tag
                    self._add_issue(
                        listitems, node,
                        f"Variable ${var_name} used in <{location}> has invalid value: {value_text}",
                        value_text, rule="xml.invalid-variable-value", subject=var_name,
                    )

            if not is_valid:
                all_valid = False

        return all_valid

    def _can_resolve(self) -> bool:
        """Whether the addon is a Skin carrying a resolver."""
        from ..skin.skin import Skin
        return isinstance(self.addon, Skin) and hasattr(self.addon, "resolver")

    def _check_file_resolved(self, root, path: str, folder: str) -> list[dict]:
        """Check the expanded tree with XmlInterpreter, include definitions left as written."""
        from ..skin.skin import Skin

        sk = self.addon
        if not isinstance(sk, Skin):
            return []

        defaults = sk.default_map.get(folder, {})
        if tree_needs_expansion(root) or any(c.get("type") in defaults for c in root.iter("control")):
            try:
                walk_root = copy.deepcopy(root)
                # the walk reads no definition body; windows check those in context
                parts = [c for c in walk_root if c.tag != "include"] if root.tag == "includes" else [walk_root]
                for part in parts:
                    sk.resolver.resolve(part, folder, source_file=path)
            except Exception:
                logger.debug("Resolution failed for %s, skipping resolved pass", path, exc_info=True)
                return []
        else:
            walk_root = root

        interpreter = XmlInterpreter(
            template_attribs=self.template_attribs,
            template_values=self.template_values,
            file_path=path,
            color_labels=self.get_color_labels(),
            theme_colors=self.addon.theme_colors if self.addon else frozenset(),
            runtime_generator=self._imports_runtime_generator(),
            constants=set(self.addon.get_constants(folder)) if self.addon else set(),
            info_names=self.known_info_names(),
            expressions=self._expression_sources(folder),
            settled_defaults=sk.settled_default_tags(folder),
            urls=UrlValues(self.get_value_sources(), self._variable_values(folder)),
        )
        issues = interpreter.interpret(walk_root)

        for item in issues:
            item.setdefault("file", path)
            item["filename"] = os.path.basename(item["file"])

        return issues

    def _expression_sources(self, folder):
        """Each expression's flattened condition, file and line, rebuilt for a new map."""
        expressions = getattr(self.addon, "expression_map", {}).get(folder, {})
        cache = vars(self).setdefault("_expression_cache", {})
        if folder in cache and cache[folder][0] is expressions:
            return cache[folder][1]
        sources = getattr(self.addon, "expression_source_map", {}).get(folder, {})
        table = {name: (flatten_expressions(text, expressions)[0], *sources[name])
                 for name, text in expressions.items() if name in sources}
        cache[folder] = (expressions, table)
        return table

    def _obsolete_window_issue(self, path, folder):
        """Issue for a window file this Kodi release never loads, unless the skin includes it."""
        name = os.path.basename(path)
        if name not in self.OBSOLETE_WINDOW_FILES:
            return None
        if os.path.normpath(path) in getattr(self.addon, "include_files", {}).get(folder, []):
            return None
        successor = self.OBSOLETE_WINDOW_FILES[name]
        message = f"{name} is not a window file in this Kodi release"
        if successor:
            message += f"; {successor} serves that window"
        return {"message": message, "file": path, "line": 1, "severity": SEVERITY_ERROR,
                "rule": "xml.obsolete-window", "subject": ""}

    def _imports_runtime_generator(self):
        """Whether addon.xml imports an addon that writes include files at runtime."""
        try:
            with open(os.path.join(self.addon.path, "addon.xml"), encoding="utf-8", errors="replace") as f:
                text = f.read()
        except (OSError, AttributeError, TypeError):
            return False
        return any(f'addon="{addon_id}"' in text for addon_id in ("script.skinvariables", "script.skinshortcuts"))

    def check_file(self, path):
        """Check one file, marking muted rows and adding kdk-ignore faults; None when excluded."""
        issues = self._file_issues(path)
        if issues is None:
            return None
        return self._reported("XML Validation", issues) + self.get_suppressions().faults_in(path)

    def _file_issues(self, path):
        """Issues of one file as written plus the resolved pass for skins; None when excluded."""
        exclude = set(self.settings.get("validation_exclude", ["shortcuts"]))
        path_parts = set(path.replace("\\", "/").split("/"))
        if exclude & path_parts:
            return None

        root = get_root_from_file(path)
        if root is None:
            return [parse_error_issue(path)]

        folder = self.addon.xml_folder_of(path)
        listitems = [parse_error_issue(path)] if path in tolerated_xml_errors else []

        obsolete = self._obsolete_window_issue(path, folder)
        if obsolete:
            listitems.append(obsolete)

        self._variable_cache = {name: node for name, (node, _) in
                                getattr(self.addon, "variable_map", {}).get(folder, {}).items()}

        for node in root.xpath(".//include[@file]"):
            issue = check_include_file_ref(self.addon, folder, node.attrib["file"])
            if issue:
                issue["line"] = node.sourceline
                listitems.append(issue)

        nodes_invalid_type = []
        if self.template_attribs:
            all_typed_controls = root.xpath(".//control[@type]")
            allowed_types_lower = {ct.lower() for ct in self.template_attribs.keys()}
            for node in all_typed_controls:
                ctrl_type = node.get("type", "").strip()
                if ctrl_type and ctrl_type.lower() not in allowed_types_lower:
                    if not is_dynamic_expression(ctrl_type):
                        nodes_invalid_type.append(node)

        for node in nodes_invalid_type:
            listitems.append(
                {
                    "line": node.sourceline,
                    "type": node.tag,
                    "identifier": node.attrib.get("type"),
                    "message": "invalid control type: %s"
                    % (node.attrib.get("type")),
                    "severity": SEVERITY_ERROR,
                    "rule": "xml.invalid-control-type",
                    "subject": node.attrib.get("type"),
                }
            )

        # resolved pass checks values; unresolved $PARAM, $VAR and constants would false-positive
        skip_value_checks = self._can_resolve()

        seen_singletons: dict = {}

        for c_type, subnodes, node, subnode in self.file_control_checks(root, file_path=path):

            if subnode.tag in INCLUDE_DEFINITION_TAGS:
                continue

            if subnode.tag not in subnodes:
                label = (
                    node.tag
                    if "type" not in node.attrib
                    else "%s type=%s" % (node.tag, node.attrib.get("type"))
                )
                listitems.append(
                    {
                        "line": subnode.sourceline,
                        "type": subnode.tag,
                        "identifier": subnode.tag,
                        "message": "invalid tag for <%s>: <%s>" % (label, subnode.tag),
                        "severity": SEVERITY_WARNING,
                        "rule": "xml.invalid-tag",
                        "subject": subnode.tag,
                    }
                )
                continue

            tmpl_val = self.template_values[c_type].get(subnode.tag)
            if subnode.text and tmpl_val:
                if not skip_value_checks:
                    self._validate_enum_value(listitems, subnode, subnode.text, tmpl_val)
                if is_dynamic_expression(subnode.text) and subnode.tag not in LITERAL_TAGS:
                    self._validate_variable_values(listitems, subnode, subnode.text, tmpl_val, folder)

            if not skip_value_checks:
                if subnode.tag in NOOP_TAGS:
                    text = (subnode.text or "").strip()
                    if not text and len(subnode) == 0 and static_value(subnode.get("condition") or "") is not False:
                        self._add_issue(listitems, subnode, f"Use 'noop' for an empty <{subnode.tag}>", severity=SEVERITY_ERROR,
                                        rule="xml.empty-action")

                if subnode.tag in BRACKET_TAGS:
                    text = (subnode.text or "").strip()
                    if (text or subnode.tag not in NOOP_TAGS) and not self._validate_brackets(listitems, subnode, text):
                        continue

                parent = node
                tag_low = subnode.tag.lower()
                allowed_multi = ALLOWED_MULTI.get(
                    (parent.tag.lower(), parent.attrib.get("type", "").lower()), set()
                )
                if (
                    len(subnode) == 0
                    and tag_low not in REPEATABLE_TAGS
                    and tag_low not in allowed_multi
                    and is_read_copy(subnode, tag_low)
                ):
                    seen = seen_singletons.setdefault(parent, set())
                    if tag_low in seen:
                        self._add_issue(listitems, subnode, f"Invalid multiple tags for {parent.tag}: <{subnode.tag}>",
                                        severity=SEVERITY_ERROR, rule="xml.duplicate-tag")
                    else:
                        seen.add(tag_low)

            for k, v in subnode.attrib.items():
                if k == "description":
                    continue
                if k not in subnodes[subnode.tag]:
                    self._add_issue(listitems, subnode, f"invalid attribute for <{subnode.tag}>: {k}, which "
                                                        f"<{node.tag} type={c_type}> ignores", k, rule="xml.invalid-attr")
                    continue
                if is_dynamic_expression(v):
                    value_type = subnodes[subnode.tag].get(k)
                    if value_type:
                        self._validate_variable_values(listitems, subnode, v, value_type, folder, tag_name=k)
                    continue
                if contains_dynamic_expression(v):
                    continue
                if (v or "").strip() == "" and k in ("target", "sortby", "sortorder", "limit"):
                    continue
                value_type = subnodes[subnode.tag][k]
                # the resolved pass checks every typed child but the structural ones
                interpreted = skip_value_checks and subnode.tag not in STRUCTURAL_TAGS
                if value_type in ["int", "position"] and not interpreted:
                    # a layout falls back to the container size for a non-numeric size
                    if subnode.tag in ALL_LAYOUT_TAGS and v == "auto":
                        continue
                    vv = v.rstrip("%r") if value_type == "position" else v
                    number_value = extract_number_value(v)
                    # <content> attributes are labels, which expand $NUMBER[]
                    if number_value and subnode.tag == "content":
                        vv = number_value
                    if not is_number(vv) and not (self.addon and v in self.addon.get_constants(folder)):
                        self._add_issue(listitems, subnode, f"invalid integer value for {k}: {v}", v, severity=SEVERITY_ERROR,
                                        rule="xml.invalid-value", subject=k)
                elif value_type == "color":
                    if (getattr(self.addon, "type", None) == "skin" and v not in self.get_color_labels()
                            and v not in self.addon.theme_colors
                            and not is_kodi_hex(v) and not is_known_info(v, self.known_info_names())):
                        self._add_issue(listitems, subnode, f"Invalid color for {k}: {v}", v, severity=SEVERITY_ERROR,
                                        rule="xml.invalid-color", subject=k)
                elif not interpreted and value_type == "bool" and attribute_bool_problem(k, v):
                    self._add_issue(listitems, subnode, attribute_bool_problem(k, v) or "", v, severity=SEVERITY_ERROR,
                                    rule="xml.misread-bool", subject=k)
                elif not interpreted:
                    self._validate_enum_value(listitems, subnode, v, value_type, attr_name=k)

                if not skip_value_checks and k == "condition" and v:
                    self._validate_brackets(listitems, subnode, v)


        for item in listitems:
            item["filename"] = os.path.basename(path)
            item["file"] = path

        if self._can_resolve():
            resolved_issues = self._check_file_resolved(root, path, folder)
            if resolved_issues:
                # source-pass issues win on collision
                seen = {(item["line"], item["message"], item.get("include_line")) for item in listitems}
                for item in resolved_issues:
                    key = (item["line"], item["message"], item.get("include_line"))
                    if key not in seen:
                        listitems.append(item)
                        seen.add(key)

        return listitems

    def file_control_checks(self, root, *, file_path=None):
        """Yield (control type, allowed tags, control, child) for every child of a typed control."""
        if file_path:
            logger.debug("Running file_control_checks for %s", os.path.basename(file_path))

        all_controls = root.xpath(".//control[@type]")

        for node in all_controls:
            c_type_raw = node.attrib.get("type", "")
            if not c_type_raw:
                continue
            c_type = c_type_raw.lower()

            subnodes = self.template_attribs.get(c_type)
            if subnodes is None:
                continue

            for subnode in node.iterchildren():
                yield (c_type, subnodes, node, subnode)
