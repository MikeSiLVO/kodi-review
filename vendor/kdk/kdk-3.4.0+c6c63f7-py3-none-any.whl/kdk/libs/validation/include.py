"""Checks the includes a skin calls and defines, and the include files it names."""

import os
import posixpath
import re

from ..utils.validation import (
    deduplicate_issues,
    find_includes_in_skinshortcuts_template,
    find_skinshortcuts_template,
    is_runtime_generated_file,
    reference_issues,
    resolve_param_in_name,
    shadowed_issues,
    should_report_progress,
)
from ..utils.files import folder_entries, is_inside, miscased_name
from ..utils.xml import get_params, get_root_from_file
from ..utils.expressions import resolve_params_in_text
from ..utils.infobool import static_value
from .constants import SEVERITY_ERROR

RUNTIME_INCLUDE_PATTERNS = [
    re.compile(r'^skinvariables-.*'),           # script.skinvariables
    re.compile(r'^skinshortcuts-.*'),            # script.skinshortcuts
    re.compile(r'^script-.*-includes$'),
]

RUNTIME_INCLUDE_FILE = re.compile(r'^script-.*-includes\.xml$', re.I)


def resolve_include_file(addon, folder, filename):
    """Resolve the path an `<include file>` opens, and the real name when only its case differs."""
    # Kodi opens the joined path with no case fallback; case matters on Linux
    parts = posixpath.normpath(filename).split("/")
    default = getattr(addon, "default_xml_folder", None)
    ordered = [folder] + ([default] if default and default != folder else [])
    near = None
    for name in ordered:
        current = os.path.join(addon.path, name)
        actual = []
        for part in parts:
            entries = folder_entries(current)
            match = part if part in entries else next(
                (e for e in entries if e.lower() == part.lower()), None)
            if match is None:
                break
            actual.append(match)
            current = os.path.join(current, match)
        else:
            if actual == parts:
                return current, None
            if near is None:
                near = "/".join(actual)
    return None, near


def check_include_file_ref(addon, folder, ref):
    """Check an `<include file>` Kodi cannot load, as an issue without the caller's location."""
    ref = (ref or "").strip()
    if not ref or "$" in ref or RUNTIME_INCLUDE_FILE.match(ref) or is_runtime_generated_file(ref):
        return None

    path, actual = resolve_include_file(addon, folder, ref)
    if path:
        root = get_root_from_file(path)
        if root is None or root.tag.lower() == "includes":
            return None
        rule, message = ("xml.missing-include-file",
                         f"Include file '{ref}' has the root <{root.tag}>, not <includes>, so Kodi loads nothing from it")
    elif not is_inside(os.path.join(addon.path, folder, ref), addon.path):
        rule, message = "xml.include-file-outside", f"Include file '{ref}' is outside the skin folder, so it never ships with the skin"
    elif actual:
        rule, message = "xml.include-file-case-mismatch", f"Case mismatch for '{ref}' (actual '{actual}')"
    else:
        rule, message = "xml.missing-include-file", f"Missing include file '{ref}'"
    return {
        'name': ref,
        'identifier': ref,
        'type': 'include',
        'message': message,
        'severity': SEVERITY_ERROR,
        'rule': rule,
        'subject': ref,
    }


class ValidationInclude:
    """Checker for undefined, unused and shadowed includes, and a misnamed Includes.xml."""

    def __init__(self, addon):
        self.addon = addon

    def _is_runtime_include(self, include_name):
        """True when the name matches a runtime-generated name pattern."""
        if not include_name:
            return False

        for pattern in RUNTIME_INCLUDE_PATTERNS:
            if pattern.match(include_name):
                return True

        return False

    def _cycle_issues(self, folder):
        """Issues for includes that reach themselves through calls, which Kodi expands forever."""
        includes = self.addon.include_map.get(folder, {})
        calls = {}
        for name, (node, _params, file_path) in includes.items():
            body = node.find("definition")
            calls[name] = [
                (callee, call.sourceline or 0, file_path)
                for call in (body if body is not None else node).iter("include")
                for callee in [call.get("content") or call.text or ""]
                if callee in includes and "name" not in call.attrib
                # a param in the condition can leave it empty in the nested copy, ending the loop
                and "$PARAM[" not in (call.get("condition") or "")
                and static_value(call.get("condition") or "true") is not False]
        issues, seen, done = [], set(), set()

        def visit(name, path):
            for callee, line, file_path in calls[name]:
                if callee in path:
                    loop = path[path.index(callee):] + [callee]
                    if frozenset(loop) not in seen:
                        seen.add(frozenset(loop))
                        issues.append({
                            'name': callee, 'type': 'include', 'file': file_path, 'line': line,
                            'message': f"Include '{callee}' reaches itself ({' > '.join(loop)}), so Kodi "
                                       f"never finishes loading a window that uses it",
                            'severity': SEVERITY_ERROR, 'rule': "includes.cycle", 'subject': " > ".join(loop),
                        })
                elif callee not in done:
                    visit(callee, path + [callee])
            done.add(name)

        for name in includes:
            if name not in done:
                visit(name, [name])
        return issues

    def check(self, progress_callback=None):
        """Check for undefined, unused, shadowed or looping includes and a misnamed Includes.xml."""
        total_includes = sum(len(self.addon.include_map.get(f, {})) for f in self.addon.xml_folders)
        total_files = sum(len(self.addon.window_files.get(f, [])) for f in self.addon.xml_folders)

        if progress_callback:
            progress_callback(f"Scanning {total_files} files for {total_includes} includes...")

        listitems = []

        def padded(name, path, line):
            if name == name.strip():
                return False
            listitems.append({
                'name': name.strip(), 'type': 'include', 'file': path, 'line': line,
                'message': f"Include '{name.strip()}' has spaces or line breaks around its name; "
                           f"Kodi keeps them and finds no include by that name",
                'severity': SEVERITY_ERROR, 'rule': "includes.undefined", 'subject': name.strip(),
            })
            return True

        default = getattr(self.addon, "default_xml_folder", None)
        for folder in self.addon.xml_folders:
            folder_path = os.path.join(self.addon.path, folder)
            actual = miscased_name(folder_path, "Includes.xml")
            # Kodi opens the default folder's copy whatever its case
            if actual and folder != default:
                if default is None:
                    effect = "Kodi does not load it on Linux"
                else:
                    fallback = f"the {default} folder's" if default else "the add-on root's"
                    effect = f"on Linux Kodi loads {fallback} Includes.xml in its place"
                listitems.append({
                    'name': actual,
                    'type': 'include',
                    'file': os.path.join(folder_path, actual),
                    'line': 1,
                    'message': f"{actual} must be named Includes.xml; {effect}",
                    'severity': SEVERITY_ERROR,
                    'rule': "includes.misnamed-includes-xml",
                    'subject': actual,
                })

            var_refs = []
            file_count = 0
            files_list = self.addon.window_files[folder]

            for xml_file in files_list:
                file_count += 1
                if progress_callback and should_report_progress(file_count, len(files_list)):
                    progress_callback(f"Scanning {xml_file} ({file_count}/{len(files_list)})...")

                path = os.path.join(self.addon.path, folder, xml_file)
                root = get_root_from_file(path)
                if root is None:
                    continue

                for node in root.xpath(".//include[not(@name)]"):
                    name = node.get("content") or node.text or ""
                    if not name.strip() or padded(name, path, node.sourceline):
                        continue

                    resolved_name = resolve_param_in_name(name)

                    # a name made only of $PARAM still counts its values as used
                    if not resolved_name.strip() and "$PARAM[" not in name:
                        continue

                    var_refs.append(
                        {
                            "line": node.sourceline,
                            "type": node.tag,
                            "file": path,
                            "name": resolved_name,
                            "raw_name": name,
                        }
                    )

                for include_node in root.iter("include"):
                    if "name" in include_node.attrib or "file" in include_node.attrib:
                        continue
                    include_name = include_node.get("content") or include_node.text or ""
                    if not include_name or include_name.startswith("$"):
                        continue

                    resolved_include_name = resolve_param_in_name(include_name)

                    include_def = None
                    params = None
                    if folder in self.addon.include_map and resolved_include_name in self.addon.include_map[folder]:
                        node_or_obj, params, file_path = self.addon.include_map[folder][resolved_include_name]
                        if hasattr(node_or_obj, 'tag'):
                            from ..skin.include import SkinInclude
                            definition = node_or_obj.find("definition")
                            include_body = definition if definition is not None else node_or_obj
                            include_def = SkinInclude(node=include_body, file=file_path)
                        else:
                            include_def = node_or_obj

                    if not include_def:
                        continue

                    call_params = get_params(include_node, "value") if "content" in include_node.attrib else {}

                    default_params = params if params else {}
                    merged_params = {**default_params, **call_params}

                    for inc_tag in include_def.node.findall(".//include"):
                        inc_name = inc_tag.text if (inc_tag.text or "").strip() else inc_tag.get("content")
                        # a padded name is reported where the call is written
                        if not inc_name or inc_name != inc_name.strip():
                            continue

                        if not inc_name or inc_name.startswith("$INFO") or inc_name.startswith("$VAR"):
                            continue

                        resolved_name, status = resolve_params_in_text(inc_name, merged_params)

                        if (status in ("ALL_RESOLVED", "NO_PARAMS") and
                            resolved_name and
                            not resolved_name.startswith("$") and
                            "$PARAM[" not in resolved_name):
                            var_refs.append(
                                {
                                    "line": inc_tag.sourceline,
                                    "type": "include",
                                    "file": include_def.file,
                                    "name": resolved_name,
                                }
                            )

            for fname in ("Font.xml", "font.xml"):
                font_path = os.path.join(self.addon.path, folder, fname)
                if not os.path.isfile(font_path):
                    continue

                if progress_callback:
                    progress_callback(f"Checking fontsets in {fname}...")

                root = get_root_from_file(font_path)
                if root is None:
                    continue

                for inc_node in root.iter("include"):
                    inc_name = inc_node.get("content") or inc_node.text or ""
                    if not inc_name.strip() or padded(inc_name, font_path, getattr(inc_node, "sourceline", 0)):
                        continue
                    var_refs.append(
                        {
                            "line": getattr(inc_node, "sourceline", 0),
                            "type": "include",
                            "file": font_path,
                            "name": inc_name,
                        }
                    )

            template_path = find_skinshortcuts_template(self.addon.path)
            if template_path:
                if progress_callback:
                    progress_callback("Checking SkinShortcuts template...")

                known_includes = set(self.addon.include_map.get(folder, {}).keys())

                template_includes = find_includes_in_skinshortcuts_template(
                    template_path, known_includes
                )

                for inc_name in template_includes:
                    var_refs.append(
                        {
                            "line": 0,
                            "type": "include",
                            "file": template_path,
                            "name": inc_name,
                        }
                    )

            include_definitions = [
                {"name": name, "type": "include", "file": file_path, "line": node.sourceline or 0}
                for name, (node, _params, file_path) in self.addon.include_map.get(folder, {}).items()
            ]

            listitems.extend(reference_issues(
                self.addon, folder, "include", var_refs, include_definitions,
                skip=lambda name: not name.strip() or name.startswith("$") or self._is_runtime_include(name)))
            listitems.extend(shadowed_issues(
                self.addon, folder,
                ("include", "include without definition", "constant", "expression", "default")))
            listitems.extend(self._cycle_issues(folder))

        undefined_count = len([i for i in listitems if "not defined" in i.get("message", "")])
        unused_count = len([i for i in listitems if "Unused" in i.get("message", "")])

        if progress_callback:
            progress_callback(f"Complete: {len(listitems)} issues ({undefined_count} undefined, {unused_count} unused)")

        return deduplicate_issues(listitems)
