"""KDK - Kodi skin validation tool."""

__version__ = "3.4.0+c6c63f7"
